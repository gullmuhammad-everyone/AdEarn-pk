import React from 'react'
import UserManagement from '../../components/admin/UserManagement'

const Users: React.FC = () => {
  return <UserManagement />
}

export default Users