import React from 'react'
import PaymentApproval from '../../components/admin/PaymentApproval'

const Payments: React.FC = () => {
  return <PaymentApproval />
}

export default Payments