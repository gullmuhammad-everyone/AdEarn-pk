import React from 'react'
import AdManagement from '../../components/admin/AdManagement'

const AdsManagement: React.FC = () => {
  return <AdManagement />
}

export default AdsManagementimport React from 'react'
import AdManagement from '../../components/admin/AdManagement'

const AdsManagement: React.FC = () => {
  return <AdManagement />
}

export default AdsManagement